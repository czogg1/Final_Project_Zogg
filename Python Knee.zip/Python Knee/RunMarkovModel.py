
import ParameterClasses as P
import MarkovModel as MarkovCls
import SupportMarkovModel as SupportMarkov

# create cohort
cohort = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.PRE)

simOutputs = cohort.simulate()

# print outcomes (means and CIs)
SupportMarkov.print_outcomes(simOutputs, 'Pre-policy implementation:')

# create cohort
cohort = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.POST)

simOutputs = cohort.simulate()

# print outcomes (means and CIs)
SupportMarkov.print_outcomes(simOutputs, 'Post-policy implementation:')
