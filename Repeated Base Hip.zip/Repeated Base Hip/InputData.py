
# simulation settings
#POP_SIZE = 111000
POP_SIZE = 1000        # reduced for trouble shooting
SIM_LENGTH = 200      # length of simulation (arbitrary time steps)
ALPHA = 0.05          # significance level for calculating confidence intervals
DISCOUNT = 0.03       # annual discount rate

DELTA_T = 1           # arbitrary time unit (length of time step, how frequently you look at the patient)

# transition matrix (baseline)
TRANS_MATRIX = [
    [0.000, 0.562,  0.438,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000],  # pre-visit
    [0.000, 0.000,  0.000,  0.902,  0.017,  0.081,  0.000,  0.000,  0.000,  0.000],  # no PME
    [0.000, 0.000,  0.000,  0.814,  0.050,  0.136,  0.000,  0.000,  0.000,  0.000],  # PME
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.280,  0.350,  0.300,  0.070],  # Hospital no complications
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.368,  0.461,  0.140,  0.031],  # Hospital with complication(s)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.345,  0.432,  0.193,  0.030],  # Hospital with transfusion
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  1.000,  0.000,  0.000,  0.000],  # Discharged to IRF (sink)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  1.000,  0.000,  0.000],  # Discharged to SNF (sink)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  1.000,  0.000],  # Discharged to HHA (sink)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  1.000],  # Discharged without care (sink)
    ]

# transition matrix after policy implementation
POLICY_MATRIX = [
    [0.000, 0.562,  0.438,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000],  # pre-visit
    [0.000, 0.000,  0.000,  0.902,  0.017,  0.081,  0.000,  0.000,  0.000,  0.000],  # no PME
    [0.000, 0.000,  0.000,  0.814,  0.050,  0.136,  0.000,  0.000,  0.000,  0.000],  # PME
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.110,  0.110,  0.670,  0.110],  # Hospital no complications
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.225,  0.225,  0.472,  0.078],  # Hospital with complication(s)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.200,  0.200,  0.540,  0.060],  # Hospital with transfusion
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  1.000,  0.000,  0.000,  0.000],  # Discharged to IRF (sink)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  1.000,  0.000,  0.000],  # Discharged to SNF (sink)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  1.000,  0.000],  # Discharged to HHA (sink)
    [0.000, 0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  1.000],  # Discharged without care (sink)
    ]

# number of cohorts
n_cohorts = 100
