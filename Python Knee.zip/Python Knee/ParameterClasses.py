
from enum import Enum
import InputData as Data


class HealthStats(Enum):
    """ health states of patients """
    PREVISIT = 0
    NOPME = 1
    PME = 2
    NOCOMP = 3
    COMP = 4
    TRANS = 5
    IRF = 6
    SNF = 7
    HHA = 8
    NOCARE = 9


class Therapies(Enum):
    """ before and after policy implementation """
    PRE = 0
    POST = 1


class ParametersFixed():
    def __init__(self, therapy):

        # selected therapy
        self._therapy = therapy

        # simulation time step
        self._delta_t = Data.DELTA_T

        # initial health state
        self._initialHealthState = HealthStats.PREVISIT

        # transition probability matrix of the selected therapy
        self._prob_matrix = []

        # annual state costs and utilities
        self._annualStateCosts = []
        self._annualStateUtilities = []

        # calculate transition probabilities depending on the time period
        if therapy == Therapies.PRE:
            self._prob_matrix = Data.TRANS_MATRIX
        else:
            self._prob_matrix = Data.POLICY_MATRIX


    def get_initial_health_state(self):
        return self._initialHealthState

    def get_delta_t(self):
        return self._delta_t

    def get_transition_prob(self, state):
        return self._prob_matrix[state.value]
