
from enum import Enum
import InputData as Data


class HealthStats(Enum):
    """ health states of patients """
    PREVISIT = 0
    IRF = 1
    SNF = 2
    HHA = 3
    NOCARE = 4
    OUTCOME = 5
    NOOUTCOME = 6


class Therapies(Enum):
    """ before and after policy implementation """
    READ_PRE = 0
    READ_POST = 1
    ED_PRE = 2
    ED_POST = 3
    COMP_PRE = 4
    COMP_POST = 5
    FURTHERCARE_PRE = 6
    FURTHERCARE_POST = 7
    WALKER_PRE = 8
    WALKER_POST = 8


class ParametersFixed():
    def __init__(self, therapy):

        # selected therapy
        self._therapy = therapy

        # simulation time step
        self._delta_t = Data.DELTA_T

        # initial health state
        self._initialHealthState = HealthStats.PREVISIT

        # transition probability matrix of the selected therapy
        self._prob_matrix = []

        # annual state costs and utilities
        self._annualStateCosts = []
        self._annualStateUtilities = []

        # calculate transition probabilities depending on the time period
        # 1. readmission
        if therapy == Therapies.READ_PRE:
            self._prob_matrix = Data.READ_PRE
        if therapy == Therapies.READ_POST:
            self._prob_matrix = Data.READ_POST
        # 2. ED visits
        if therapy == Therapies.ED_PRE:
            self._prob_matrix = Data.ED_PRE
        if therapy == Therapies.ED_POST:
            self._prob_matrix = Data.ED_POST
        # 3. PCP visits
        if therapy == Therapies.COMP_PRE:
            self._prob_matrix = Data.COMP_PRE
        if therapy == Therapies.COMP_POST:
            self._prob_matrix = Data.COMP_POST
        # 4. required further care
        if therapy == Therapies.FURTHERCARE_PRE:
            self._prob_matrix = Data.FURTHERCARE_PRE
        if therapy == Therapies.FURTHERCARE_POST:
            self._prob_matrix = Data.FURTHERCARE_POST
        # 5. walker requirement
        if therapy == Therapies.WALKER_PRE:
            self._prob_matrix = Data.WALKER_PRE
        if therapy == Therapies.WALKER_POST:
            self._prob_matrix = Data.WALKER_POST


    def get_initial_health_state(self):
        return self._initialHealthState

    def get_delta_t(self):
        return self._delta_t

    def get_transition_prob(self, state):
        return self._prob_matrix[state.value]
