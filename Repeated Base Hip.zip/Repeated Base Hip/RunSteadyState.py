
import CompareCohorts as Compare


# create a set of cohorts
cohorts = Compare.SetofCohorts(id=0)

# simulate the cohorts
sim_output = cohorts.simulation()

