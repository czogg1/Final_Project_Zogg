
import ParameterClasses as P
import MarkovModel as MarkovCls
import InputData as Data
import scr.FormatFunctions as F
import scr.StatisticalClasses as Stat
import scr.FigureSupport as Figs


class SetofCohorts:
    def __init__(self, id):
        self._id = id
        self._change_irf = []       # list of differences in irf probability
        self._change_snf = []       # list of differences in snf probability
        self._change_hha = []       # list of differences in hha probability
        self._change_nocare = []    # list of differences in no care probability

        self._irf_pre = []
        self._irf_post = []
        self._snf_pre = []
        self._snf_post = []
        self._hha_post = []
        self._hha_pre = []
        self._nocare_pre = []
        self._nocare_post = []

        self._n_cohorts = Data.n_cohorts

    def simulation(self):
        for n in range(self._n_cohorts):
            # create a new cohort pair and simulate them
            cohort_pre = MarkovCls.Cohort(id=self._id*self._n_cohorts+n, therapy=P.Therapies.PRE)
            simOutputs_pre = cohort_pre.simulate()

            self._irf_pre.append(simOutputs_pre.get_ave_irf_count())
            self._snf_pre.append(simOutputs_pre.get_ave_snf_count())
            self._hha_pre.append(simOutputs_pre.get_hha_count())
            self._nocare_pre.append(simOutputs_pre.get_ave_nocare_count())

            cohort_post = MarkovCls.Cohort(id=self._id*self._n_cohorts+n, therapy=P.Therapies.POST)
            simOutputs_post = cohort_post.simulate()

            self._irf_post.append(simOutputs_post.get_ave_irf_count())
            self._snf_post.append(simOutputs_post.get_ave_snf_count())
            self._hha_post.append(simOutputs_post.get_ave_hha_count())
            self._nocare_post.append(simOutputs_post.get_ave_nocare_count())

        self._sumStat_irf_pre = \
            Stat.SummaryStat(name='IRF pre', data=self._irf_pre)
        self._sumStat_snf_pre = \
            Stat.SummaryStat(name='IRF pre', data=self._snf_pre)
        self._sumStat_hha_pre = \
            Stat.SummaryStat(name='IRF pre', data=self._hha_pre)
        self._sumStat_nocare_pre = \
            Stat.SummaryStat(name='IRF pre', data=self._nocare_pre)

        self._sumStat_irf_post = \
            Stat.SummaryStat(name='IRF pre', data=self._irf_post)
        self._sumStat_snf_post = \
            Stat.SummaryStat(name='IRF pre', data=self._snf_post)
        self._sumStat_hha_post = \
            Stat.SummaryStat(name='IRF pre', data=self._hha_post)
        self._sumStat_nocare_post = \
            Stat.SummaryStat(name='IRF pre', data=self._nocare_post)

        hha_pre_text = F.format_estimate_interval(
            estimate=self._sumStat_hha_pre.get_mean(),
            interval=self._sumStat_hha_pre.get_t_CI(alpha=0.05), deci=4)
        print(hha_pre_text)

        hha_post_text = F.format_estimate_interval(
            estimate=self._sumStat_hha_post.get_mean(),
            interval=self._sumStat_hha_post.get_t_CI(alpha=0.05), deci=4)
        print(hha_post_text)

        irf_change_text = F.format_estimate_interval(
            estimate=Stat.DifferenceStatIndp(name='IRF', x=self._irf_post, y_ref=self._irf_pre).get_mean(),
            interval=Stat.DifferenceStatIndp(name='IRF', x=self._irf_post, y_ref=self._irf_pre).get_t_CI(alpha=0.05),
            deci=4)

        snf_change_text = F.format_estimate_interval(
            estimate=Stat.DifferenceStatIndp(name='IRF', x=self._snf_post, y_ref=self._snf_pre).get_mean(),
            interval=Stat.DifferenceStatIndp(name='IRF', x=self._snf_post, y_ref=self._snf_pre).get_t_CI(alpha=0.05),
            deci=4)

        """hha_change_text = F.format_estimate_interval(
            estimate=Stat.DifferenceStatIndp(name='IRF', x=self._hha_post, y_ref=self._hha_pre).get_mean(),
            interval=Stat.DifferenceStatIndp(name='IRF', x=self._hha_post, y_ref=self._hha_pre).get_t_CI(alpha=0.05),
            deci=4)"""

        nocare_change_text = F.format_estimate_interval(
            estimate=Stat.DifferenceStatIndp(name='IRF', x=self._nocare_post, y_ref=self._nocare_pre).get_mean(),
            interval=Stat.DifferenceStatIndp(name='IRF', x=self._nocare_post, y_ref=self._nocare_pre).get_t_CI(alpha=0.05),
            deci=4)

        print('Average difference in IRF across 100 random cohorts:', irf_change_text)
        print('Average difference in SNF across 100 random cohorts:', snf_change_text)
        #print('Average difference in HHA across 100 random cohorts:', hha_change_text)
        print('Average difference in no care across 100 random cohorts:', nocare_change_text)


        # histograms
        set_of_game_rewards = [self._irf_pre, self._irf_post]

        Figs.graph_histograms(
            data_sets=set_of_game_rewards,
            title='Results of 100 random cohorts: Inpatient Rehabilitation Facility (IRF)',
            x_label='Probabilty of discharge to IRF',
            y_label='Counts',
            bin_width=0.002,
            legend=['Pre-policy implementation', 'Post-policy implementation'],
            transparency=0.6, x_range=[0.00, 0.50], y_range=[0, 20])

        set_of_game_rewards = [self._snf_pre, self._snf_post]

        Figs.graph_histograms(
            data_sets=set_of_game_rewards,
            title='Results of 100 random cohorts: Skilled Nursing Facility (SNF)',
            x_label='Probabilty of discharge to SNF',
            y_label='Counts',
            bin_width=0.002,
            legend=['Pre-policy implementation', 'Post-policy implementation'],
            transparency=0.6, x_range=[0.00, 0.50], y_range=[0, 20])

        set_of_game_rewards = [self._hha_pre, self._hha_post]

        """Figs.graph_histograms(
            data_sets=set_of_game_rewards,
            title='Results of 100 random cohorts: Home Health Agency (HHA)',
            x_label='Probabilty of discharge to HHA',
            y_label='Counts',
            bin_width=0.01,
            legend=['Pre-policy implementation', 'Post-policy implementation'],
            transparency=0.6, x_range=[0.00, 0.50], y_range=[0, 20])"""

        set_of_game_rewards = [self._nocare_pre, self._nocare_post]

        Figs.graph_histograms(
            data_sets=set_of_game_rewards,
            title='Results of 100 random cohorts: No post-discharge rehabilitation',
            x_label='Probabilty of discharge home without care',
            y_label='Counts',
            bin_width=0.002,
            legend=['Pre-policy implementation', 'Post-policy implementation'],
            transparency=0.6, x_range=[0.00, 0.50], y_range=[0, 20])
