
import InputData as Settings
import scr.FormatFunctions as F
import scr.StatisticalClasses as Stat


def print_outcomes(simOutput, therapy_name):
    """ prints the outcomes of a simulated cohort
    :param simOutput: output of a simulated cohort
    :param therapy_name: the name of the time period
    """

    # probability (mean) and CI of outcome
    outcome_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_outcome_count().get_mean(),
        interval=simOutput.get_sumStat_outcome_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # print outcomes
    print(therapy_name)
    print("     Estimate of the probability and {:.{prec}%}CI of outcome:".format(1 - Settings.ALPHA, prec=0),
          outcome_mean_CI_text)

def print_comparative_outcomes(simOutputs_pre, simOutputs_post):
    """ prints average 'increase' in outcome before and after policy implementation
    :param simOutputs_pre: output of a cohort simulated prior to policy implementation
    :param simOutputs_post: output of a cohort simulated after policy implementation
    """

    # increase in outcome
    increase_outcome_count = Stat.DifferenceStatIndp(
        name='Increase in outcome',
        x=simOutputs_post.get_outcome_count(),
        y_ref=simOutputs_pre.get_outcome_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_outcome_count.get_mean(),
        interval=increase_outcome_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in outcome "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)