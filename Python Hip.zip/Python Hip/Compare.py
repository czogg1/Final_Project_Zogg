import ParameterClasses as P
import MarkovModel as MarkovCls
import SupportMarkovModel as SupportMarkov

# simululating pre-policy implementation
# create a cohort
cohort_pre = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.PRE)
# simulate the cohort
simOutputs_pre = cohort_pre.simulate()

# simulating post-policy implementation
# create a cohort
cohort_post = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.POST)
# simulate the cohort
simOutputs_post = cohort_post.simulate()

# print the period-specific discharge disposition
SupportMarkov.print_outcomes(simOutputs_pre, "Pre-policy implementation:")
SupportMarkov.print_outcomes(simOutputs_post, "Post-policy implementation:")

# print the comparative outcomes
print("Change in discharge disposition")
SupportMarkov.print_comparative_outcomes(simOutputs_pre, simOutputs_post)
