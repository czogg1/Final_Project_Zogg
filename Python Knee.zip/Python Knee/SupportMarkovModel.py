
import InputData as Settings
import scr.FormatFunctions as F
import scr.StatisticalClasses as Stat


def print_outcomes(simOutput, therapy_name):
    """ prints the outcomes of a simulated cohort
    :param simOutput: output of a simulated cohort
    :param therapy_name: the name of the time period
    """

    # probability (mean) and CI of discharge to IRF
    irf_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_irf_count().get_mean(),
        interval=simOutput.get_sumStat_irf_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # probability (mean) and CI of discharge to SNF
    snf_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_snf_count().get_mean(),
        interval=simOutput.get_sumStat_snf_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # probability (mean) and CI of discharge to HHA
    hha_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_hha_count().get_mean(),
        interval=simOutput.get_sumStat_hha_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # probability (mean) and CI of discharge to home without care
    nocare_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_nocare_count().get_mean(),
        interval=simOutput.get_sumStat_nocare_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)



    los_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_los_count().get_mean(),
        interval=simOutput.get_sumStat_los_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    ambulation_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_ambulation_count().get_mean(),
        interval=simOutput.get_sumStat_ambulation_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    intensity_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_intensity_count().get_mean(),
        interval=simOutput.get_sumStat_intensity_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    pttime_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_pttime_count().get_mean(),
        interval=simOutput.get_sumStat_pttime_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    ottime_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_ottime_count().get_mean(),
        interval=simOutput.get_sumStat_ottime_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    psychtime_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_psychtime_count().get_mean(),
        interval=simOutput.get_sumStat_psychtime_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    ptdays_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_ptdays_count().get_mean(),
        interval=simOutput.get_sumStat_ptdays_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    otdays_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_otdays_count().get_mean(),
        interval=simOutput.get_sumStat_otdays_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    psychdays_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_psychdays_count().get_mean(),
        interval=simOutput.get_sumStat_psychdays_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)


    motorfim_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_motorfim_count().get_mean(),
        interval=simOutput.get_sumStat_motorfim_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    pcs_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_pcs_count().get_mean(),
        interval=simOutput.get_sumStat_pcs_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    mcs_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_mcs_count().get_mean(),
        interval=simOutput.get_sumStat_mcs_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    fimgain_total_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_fimgain_total_count().get_mean(),
        interval=simOutput.get_sumStat_fimgain_total_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    fimgain_atod_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_fimgain_atod_count().get_mean(),
        interval=simOutput.get_sumStat_fimgain_atod_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    fimgain_dtof_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_fimgain_dtof_count().get_mean(),
        interval=simOutput.get_sumStat_fimgain_dtof_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # print outcomes
    print(therapy_name)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to IRF:".format(1 - Settings.ALPHA, prec=0),
          irf_mean_CI_text)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to SNF:".format(1 - Settings.ALPHA, prec=0),
          snf_mean_CI_text)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to HHA:".format(1 - Settings.ALPHA, prec=0),
          hha_mean_CI_text)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to home without care:".format(1 - Settings.ALPHA, prec=0),
          nocare_mean_CI_text)

    print("")
    print("")
    print("     Estimate of the mean and {:.{prec}%}CI of facility-based rehabilitation days:".format(1 - Settings.ALPHA, prec=0),
          los_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of ambulation distance in feet:".format(1 - Settings.ALPHA, prec=0),
          ambulation_mean_CI_text)
    print("Therapy ouctomes:")
    print("     Estimate of the mean and {:.{prec}%}CI of therapy intensity (min/rehab days):".format(1 - Settings.ALPHA, prec=0),
          intensity_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of OT min:".format(1 - Settings.ALPHA, prec=0),
          ottime_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of PT min:".format(1 - Settings.ALPHA, prec=0),
          pttime_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of counseling min:".format(1 - Settings.ALPHA, prec=0),
          psychtime_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of OT days:".format(1 - Settings.ALPHA, prec=0),
          otdays_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of PT days:".format(1 - Settings.ALPHA, prec=0),
          ptdays_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of counseling days:".format(1 - Settings.ALPHA, prec=0),
          psychdays_mean_CI_text)
    print("Quality of life outcomes:")
    print("     Estimate of the mean and {:.{prec}%}CI of motor FIM score:".format(1 - Settings.ALPHA, prec=0),
          motorfim_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of transformed PCS (SF-12):".format(1 - Settings.ALPHA, prec=0),
          pcs_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of transformed MCS (SF-12):".format(1 - Settings.ALPHA, prec=0),
          mcs_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of motor FIM gains overall:".format(1 - Settings.ALPHA, prec=0),
          fimgain_total_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of motor FIM gains admission to discharge".format(1 - Settings.ALPHA, prec=0),
          fimgain_atod_mean_CI_text)
    print("     Estimate of the mean and {:.{prec}%}CI of motor FIM gains post-discharge:".format(1 - Settings.ALPHA, prec=0),
          fimgain_dtof_mean_CI_text)

    print("")
    print("")

def print_comparative_outcomes(simOutputs_pre, simOutputs_post):
    """ prints average 'increase' in discharge disposition before and after policy implementation
    :param simOutputs_pre: output of a cohort simulated prior to policy implementation
    :param simOutputs_post: output of a cohort simulated after policy implementation
    """

    # increase in IRF
    increase_irf_count = Stat.DifferenceStatIndp(
        name='Increase in IRF',
        x=simOutputs_post.get_irf_count(),
        y_ref=simOutputs_pre.get_irf_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_irf_count.get_mean(),
        interval=increase_irf_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in IRF "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in SNF
    increase_snf_count = Stat.DifferenceStatIndp(
        name='Increase in SNF',
        x=simOutputs_post.get_snf_count(),
        y_ref=simOutputs_pre.get_snf_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_snf_count.get_mean(),
        interval=increase_snf_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in SNF "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in HHA
    increase_hha_count = Stat.DifferenceStatIndp(
        name='Increase in HHA',
        x=simOutputs_post.get_hha_count(),
        y_ref=simOutputs_pre.get_hha_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_hha_count.get_mean(),
        interval=increase_hha_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in HHA "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in no care
    increase_nocare_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_nocare_count(),
        y_ref=simOutputs_pre.get_nocare_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_nocare_count.get_mean(),
        interval=increase_nocare_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in discharge home without care "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)


    # increase in los
    increase_los_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_los_count(),
        y_ref=simOutputs_pre.get_los_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_los_count.get_mean(),
        interval=increase_los_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in facility-based rehabiliation days "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in ambulation
    increase_ambulation_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_ambulation_count(),
        y_ref=simOutputs_pre.get_ambulation_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_ambulation_count.get_mean(),
        interval=increase_ambulation_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in ambulation feet "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in intensity
    increase_intensity_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_intensity_count(),
        y_ref=simOutputs_pre.get_intensity_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_intensity_count.get_mean(),
        interval=increase_intensity_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in rehabilitation intensity "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in PT time
    increase_pttime_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_pttime_count(),
        y_ref=simOutputs_pre.get_pttime_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_pttime_count.get_mean(),
        interval=increase_pttime_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in PT time "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in OT time
    increase_ottime_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_ottime_count(),
        y_ref=simOutputs_pre.get_ottime_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_ottime_count.get_mean(),
        interval=increase_ottime_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in OT time "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in counseling time
    increase_psychtime_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_psychtime_count(),
        y_ref=simOutputs_pre.get_psychtime_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_psychtime_count.get_mean(),
        interval=increase_psychtime_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in couseling time "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in PT days
    increase_ptdays_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_ptdays_count(),
        y_ref=simOutputs_pre.get_ptdays_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_ptdays_count.get_mean(),
        interval=increase_ptdays_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in PT days "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in OT days
    increase_otdays_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_otdays_count(),
        y_ref=simOutputs_pre.get_otdays_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_otdays_count.get_mean(),
        interval=increase_otdays_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in OT days "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in psych days
    increase_psychdays_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_psychdays_count(),
        y_ref=simOutputs_pre.get_psychdays_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_psychdays_count.get_mean(),
        interval=increase_psychdays_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in counseling days "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)



    # increase in motor FIM
    increase_motorfim_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_motorfim_count(),
        y_ref=simOutputs_pre.get_motorfim_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_motorfim_count.get_mean(),
        interval=increase_motorfim_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in motor FIM score "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in PCS
    increase_pcs_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_pcs_count(),
        y_ref=simOutputs_pre.get_pcs_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_pcs_count.get_mean(),
        interval=increase_pcs_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in transformed PCS (SF-12) "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in MCS
    increase_mcs_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_mcs_count(),
        y_ref=simOutputs_pre.get_mcs_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_mcs_count.get_mean(),
        interval=increase_mcs_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in transformed MCS (SF-12) "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in FIM total gain
    increase_fimgain_total_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_fimgain_total_count(),
        y_ref=simOutputs_pre.get_fimgain_total_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_fimgain_total_count.get_mean(),
        interval=increase_fimgain_total_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in motor FIM score (total) "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in FIM atod
    increase_fimgain_atod_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_fimgain_atod_count(),
        y_ref=simOutputs_pre.get_fimgain_atod_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_fimgain_atod_count.get_mean(),
        interval=increase_fimgain_atod_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in motor FIM score (admission to discharge) "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in FIM dtof
    increase_fimgain_dtof_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_fimgain_dtof_count(),
        y_ref=simOutputs_pre.get_fimgain_dtof_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_fimgain_dtof_count.get_mean(),
        interval=increase_fimgain_dtof_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in motor FIM score (post-discharge) "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)
