import ParameterClasses as P
import MarkovModel as MarkovCls
import SupportMarkovModel as SupportMarkov

# 1. Readmission

# simulating pre-policy implementation
# create a cohort
cohort_pre = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.READ_PRE)
# simulate the cohort
simOutputs_pre = cohort_pre.simulate()

# simulating post-policy implementation
# create a cohort
cohort_post = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.READ_POST)
# simulate the cohort
simOutputs_post = cohort_post.simulate()

# print the period-specific discharge disposition
SupportMarkov.print_outcomes(simOutputs_pre, "Pre-policy readmission 90 days:")
SupportMarkov.print_outcomes(simOutputs_post, "Post-policy readmission 90 days:")

# print the comparative outcomes
print("Change in discharge disposition")
SupportMarkov.print_comparative_outcomes(simOutputs_pre, simOutputs_post)


# 2. ED visits

# simulating pre-policy implementation
# create a cohort
cohort_pre = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.ED_PRE)
# simulate the cohort
simOutputs_pre = cohort_pre.simulate()

# simulating post-policy implementation
# create a cohort
cohort_post = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.ED_POST)
# simulate the cohort
simOutputs_post = cohort_post.simulate()

# print the period-specific discharge disposition
SupportMarkov.print_outcomes(simOutputs_pre, "Pre-policy ED visits 90 days:")
SupportMarkov.print_outcomes(simOutputs_post, "Post-policy ED visits 90 days:")

# print the comparative outcomes
print("Change in discharge disposition")
SupportMarkov.print_comparative_outcomes(simOutputs_pre, simOutputs_post)


# 3. Complications

# simulating pre-policy implementation
# create a cohort
cohort_pre = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.COMP_PRE)
# simulate the cohort
simOutputs_pre = cohort_pre.simulate()

# simulating post-policy implementation
# create a cohort
cohort_post = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.COMP_POST)
# simulate the cohort
simOutputs_post = cohort_post.simulate()

# print the period-specific discharge disposition
SupportMarkov.print_outcomes(simOutputs_pre, "Pre-policy complications 90 days:")
SupportMarkov.print_outcomes(simOutputs_post, "Post-policy complications 90 days:")

# print the comparative outcomes
print("Change in discharge disposition")
SupportMarkov.print_comparative_outcomes(simOutputs_pre, simOutputs_post)


# 4. Requirement for further care

# simulating pre-policy implementation
# create a cohort
cohort_pre = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.FURTHERCARE_PRE)
# simulate the cohort
simOutputs_pre = cohort_pre.simulate()

# simulating post-policy implementation
# create a cohort
cohort_post = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.FURTHERCARE_POST)
# simulate the cohort
simOutputs_post = cohort_post.simulate()

# print the period-specific discharge disposition
SupportMarkov.print_outcomes(simOutputs_pre, "Pre-policy requirement for further care:")
SupportMarkov.print_outcomes(simOutputs_post, "Post-policy requirement for further care:")

# print the comparative outcomes
print("Change in discharge disposition")
SupportMarkov.print_comparative_outcomes(simOutputs_pre, simOutputs_post)


# 5. Requirement for a walker

# simulating pre-policy implementation
# create a cohort
cohort_pre = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.WALKER_PRE)
# simulate the cohort
simOutputs_pre = cohort_pre.simulate()

# simulating post-policy implementation
# create a cohort
cohort_post = MarkovCls.Cohort(
    id=0,
    therapy=P.Therapies.WALKER_POST)
# simulate the cohort
simOutputs_post = cohort_post.simulate()

# print the period-specific discharge disposition
SupportMarkov.print_outcomes(simOutputs_pre, "Pre-policy requirement for walker at home:")
SupportMarkov.print_outcomes(simOutputs_post, "Post-policy requirement for walker at home:")

# print the comparative outcomes
print("Change in discharge disposition")
SupportMarkov.print_comparative_outcomes(simOutputs_pre, simOutputs_post)
