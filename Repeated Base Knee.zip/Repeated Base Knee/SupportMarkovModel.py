
import InputData as Settings
import scr.FormatFunctions as F
import scr.StatisticalClasses as Stat


def print_outcomes(simOutput, therapy_name):
    """ prints the outcomes of a simulated cohort
    :param simOutput: output of a simulated cohort
    :param therapy_name: the name of the time period
    """

    # probability (mean) and CI of discharge to IRF
    irf_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_irf_count().get_mean(),
        interval=simOutput.get_sumStat_irf_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # probability (mean) and CI of discharge to SNF
    snf_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_snf_count().get_mean(),
        interval=simOutput.get_sumStat_snf_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # probability (mean) and CI of discharge to HHA
    hha_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_hha_count().get_mean(),
        interval=simOutput.get_sumStat_hha_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # probability (mean) and CI of discharge to home without care
    nocare_mean_CI_text = F.format_estimate_interval(
        estimate=simOutput.get_sumStat_nocare_count().get_mean(),
        interval=simOutput.get_sumStat_nocare_count().get_t_CI(alpha=Settings.ALPHA),
        deci=4)

    # print outcomes
    print(therapy_name)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to IRF:".format(1 - Settings.ALPHA, prec=0),
          irf_mean_CI_text)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to SNF:".format(1 - Settings.ALPHA, prec=0),
          snf_mean_CI_text)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to HHA:".format(1 - Settings.ALPHA, prec=0),
          hha_mean_CI_text)
    print("     Estimate of the probability and {:.{prec}%}CI of discharge to home without care:".format(1 - Settings.ALPHA, prec=0),
          nocare_mean_CI_text)


def print_comparative_outcomes(simOutputs_pre, simOutputs_post):
    """ prints average 'increase' in discharge disposition before and after policy implementation
    :param simOutputs_pre: output of a cohort simulated prior to policy implementation
    :param simOutputs_post: output of a cohort simulated after policy implementation
    """

    # increase in IRF
    increase_irf_count = Stat.DifferenceStatIndp(
        name='Increase in IRF',
        x=simOutputs_post.get_irf_count(),
        y_ref=simOutputs_pre.get_irf_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_irf_count.get_mean(),
        interval=increase_irf_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in IRF "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in SNF
    increase_snf_count = Stat.DifferenceStatIndp(
        name='Increase in SNF',
        x=simOutputs_post.get_snf_count(),
        y_ref=simOutputs_pre.get_snf_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_snf_count.get_mean(),
        interval=increase_snf_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in SNF "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in HHA
    increase_hha_count = Stat.DifferenceStatIndp(
        name='Increase in HHA',
        x=simOutputs_post.get_hha_count(),
        y_ref=simOutputs_pre.get_hha_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_hha_count.get_mean(),
        interval=increase_hha_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in HHA "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)

    # increase in no care
    increase_nocare_count = Stat.DifferenceStatIndp(
        name='Increase in home without care',
        x=simOutputs_post.get_nocare_count(),
        y_ref=simOutputs_pre.get_nocare_count())

        # estimate and CI
    estimate_CI = F.format_estimate_interval(
        estimate=increase_nocare_count.get_mean(),
        interval=increase_nocare_count.get_t_CI(alpha=Settings.ALPHA),
        deci=4)
    print("Average increase in discharge home without care "
          "and {:.{prec}%}CI:".format(1 - Settings.ALPHA, prec=0),
          estimate_CI)
