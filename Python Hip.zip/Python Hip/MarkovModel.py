
import scr.SamplePathClasses as PathCls
import scr.StatisticalClasses as StatCls
import scr.RandomVariantGenerators as rndClasses
import ParameterClasses as P
import InputData as Data

# patient class simulates patient, patient monitor follows patient, cohort simulates a cohort,
# cohort outcome extracts info from simulation and returns it back


class Patient:  # when you store in self then all the things in that class have access to it
    def __init__(self, id, parameters):
        """ initiates a patient
        :param id: ID of the patient
        :param parameters: parameter object
        """

        self._id = id
        # random number generator
        self._rng = None
        # parameters
        self._param = parameters
        # state monitor
        self._stateMonitor = PatientStateMonitor(parameters)
        # simulate time step
        self._delta_t = parameters.get_delta_t()    # length of time step!

    def simulate(self, sim_length):
        """ simulate the patient over the specified simulation length """
        # random number generator for this patient
        self._rng = rndClasses.RNG(self._id)  # from now on use random number generator from support library

        k = 0  # current time step

        # while the patient is alive and simulation length is not yet reached
        while self._stateMonitor.get_if_alive() and k*self._delta_t < sim_length:
            # find transition probabilities of future state
            trans_prob = self._param.get_transition_prob(self._stateMonitor.get_current_state())
            # create an empirical distribution
            empirical_dist = rndClasses.Empirical(trans_prob)
            # sample from the empirical distribution to get a new state
            # (return an intger from {0, 1, 2, ...}
            new_state_index = empirical_dist.sample(self._rng) # pass RNG

            # update health state
            self._stateMonitor.update(k, P.HealthStats(new_state_index))

            # increment time step
            k += 1

    def get_survival_time(self):
        """ returns the patient's survival time """
        return self._stateMonitor.get_survival_time()

    def get_irf_count(self):
        """ returns if discharged to IRF """
        return self._stateMonitor.get_irf_count()

    def get_snf_count(self):
        """ returns if discharged to SNF """
        return self._stateMonitor.get_snf_count()

    def get_hha_count(self):
        """ returns if discharged to HHA """
        return self._stateMonitor.get_hha_count()

    def get_nocare_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_nocare_count()


    def get_los_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_los_count()

    def get_ambulation_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_ambulation_count()

    def get_intensity_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_intensity_count()

    def get_ottime_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_ottime_count()

    def get_pttime_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_pttime_count()

    def get_psychtime_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_psychtime_count()

    def get_otdays_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_otdays_count()

    def get_ptdays_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_ptdays_count()

    def get_psychdays_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_psychdays_count()

    def get_motorfim_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_motorfim_count()

    def get_pcs_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_pcs_count()

    def get_mcs_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_mcs_count()

    def get_fimgain_total_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_fimgain_total_count()

    def get_fimgain_atod_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_fimgain_atod_count()

    def get_fimgain_dtof_count(self):
        """ returns if discharged home without care """
        return self._stateMonitor.get_fimgain_dtof_count()


class PatientStateMonitor:
    """ to update patient outcomes throughout the simulation """
    def __init__(self, parameters):
        """
        :param parameters: patient parameters
        """
        # current health state
        self._currentState = parameters.get_initial_health_state()
        self._delta_t = parameters.get_delta_t()
        self._survivalTime = 0
        self._ifDevelopedStroke = False
        self._strokecount = 0

        self._ifIRF = False
        self._ifSNF = False
        self._ifHHA = False
        self._ifNoCare = False

        # continuous outcome dummies
        self._los = 0           # time in facility-based rehabilitation
        self._ambulation = 0    # ambulation distance in feet

            # therapy outcomes
        self._ottime = 0        # total OT in min
        self._pttime = 0        # total PT in min
        self._psychtime = 0     # total psych counseling in min
        self._otdays = 0        # number of OT days
        self._ptdays = 0        # number of PT days
        self._psychdays = 0     # number of psych counseling days
        self._intensity = 0     # overall therapy intensity min/therapy days

            # quality of life
        self._motorfim = 0      # motor FIM score
        self._pcs = 0           # transformed SF-12 Physical Component Score
        self._mcs = 0           # transformed SF-12 Mental Component Score
        self._fimgain_atod = 0  # motor FIM gain admission to discharge
        self._fimgain_dtof = 0  # motor FIM gain discharge to follow-up
        self._fimgain_total = 0     # motor FIM gain admission to follow-up

    def update(self, k, next_state):
        """
        :param k: current time step
        :param next_state: next state
        """
        # updates state of patient
        # if the patient has been discharged, do nothing
        if not self.get_if_alive():
            return

        # update survival time
        if next_state in [P.HealthStats.IRF, P.HealthStats.SNF, P.HealthStats.HHA, P.HealthStats.NOCARE]:
            self._survivalTime = (k+0.5) * self._delta_t  # k is number of steps its been, delta t is length of time
            # step, the 0.5 is a half cycle correction

        # update discharge disposition trackers
        if next_state is P.HealthStats.IRF:
            self._ifIRF = True
        if next_state is P.HealthStats.SNF:
            self._ifSNF = True
        if next_state is P.HealthStats.HHA:
            self._ifHHA = True
        if next_state is P.HealthStats.NOCARE:
            self._ifNoCare = True

        # attach continuous outcomes (dicotomous probabilities in second model)
        # los
        if next_state is P.HealthStats.IRF:
            self._los = 10.3
        if next_state is P.HealthStats.SNF:
            self._los = 20.0
        if next_state is P.HealthStats.HHA:
            self._los = 0
        if next_state is P.HealthStats.NOCARE:
            self._los = 0

        # ambulation
        if next_state is P.HealthStats.IRF:
            self._ambulation = 380
        if next_state is P.HealthStats.SNF:
            self._ambulation = 289
        if next_state is P.HealthStats.HHA:
            self._ambulation = 250
        if next_state is P.HealthStats.NOCARE:
            self._ambulation = 100

        # OT time
        if next_state is P.HealthStats.IRF:
            self._ottime = 589.8
        if next_state is P.HealthStats.SNF:
            self._ottime = 416.1
        if next_state is P.HealthStats.HHA:
            self._ottime = 19.8
        if next_state is P.HealthStats.NOCARE:
            self._ottime = 0

        # PT time
        if next_state is P.HealthStats.IRF:
            self._pttime = 720.2
        if next_state is P.HealthStats.SNF:
            self._pttime = 566.2
        if next_state is P.HealthStats.HHA:
            self._pttime = 400.3
        if next_state is P.HealthStats.NOCARE:
            self._pttime = 0

        # psych time
        if next_state is P.HealthStats.IRF:
            self._psychtime = 8.9
        if next_state is P.HealthStats.SNF:
            self._psychtime = 0.4
        if next_state is P.HealthStats.HHA:
            self._psychtime = 0
        if next_state is P.HealthStats.NOCARE:
            self._psychtime = 0

        # OT days
        if next_state is P.HealthStats.IRF:
            self._otdays = 7.99
        if next_state is P.HealthStats.SNF:
            self._otdays = 9.14
        if next_state is P.HealthStats.HHA:
            self._otdays = 0.41
        if next_state is P.HealthStats.NOCARE:
            self._otdays = 0

        # PT days
        if next_state is P.HealthStats.IRF:
            self._ptdays = 8.64
        if next_state is P.HealthStats.SNF:
            self._ptdays = 9.86
        if next_state is P.HealthStats.HHA:
            self._ptdays = 7.42
        if next_state is P.HealthStats.NOCARE:
            self._ptdays = 0

        # psych days
        if next_state is P.HealthStats.IRF:
            self._psychdays = 0.22
        if next_state is P.HealthStats.SNF:
            self._psychdays = 0.01
        if next_state is P.HealthStats.HHA:
            self._psychdays = 0
        if next_state is P.HealthStats.NOCARE:
            self._psychdays = 0

        # therapy intensity
        if next_state is P.HealthStats.IRF:
            self._intensity = 131.1
        if next_state is P.HealthStats.SNF:
            self._intensity = 87.9
        if next_state is P.HealthStats.HHA:
            self._intensity = 23.3
        if next_state is P.HealthStats.NOCARE:
            self._intensity = 0

        # motor FIM
        if next_state is P.HealthStats.IRF:
            self._motorfim = 87.4
        if next_state is P.HealthStats.SNF:
            self._motorfim = 85.6
        if next_state is P.HealthStats.HHA:
            self._motorfim = 80
        if next_state is P.HealthStats.NOCARE:
            self._motorfim = 65

        # PCS
        if next_state is P.HealthStats.IRF:
            self._pcs = 52.8
        if next_state is P.HealthStats.SNF:
            self._pcs = 49.1
        if next_state is P.HealthStats.HHA:
            self._pcs = 45
        if next_state is P.HealthStats.NOCARE:
            self._pcs = 35

        # MCS
        if next_state is P.HealthStats.IRF:
            self._mcs = 44.7
        if next_state is P.HealthStats.SNF:
            self._mcs = 43.8
        if next_state is P.HealthStats.HHA:
            self._mcs = 40
        if next_state is P.HealthStats.NOCARE:
            self._mcs = 35

        # FIM admission to discharge
        if next_state is P.HealthStats.IRF:
            self._fimgain_atod = 26.7
        if next_state is P.HealthStats.SNF:
            self._fimgain_atod = 20.9
        if next_state is P.HealthStats.HHA:
            self._fimgain_atod = 0
        if next_state is P.HealthStats.NOCARE:
            self._fimgain_atod = 0

        # FIM discharge to follow-up
        if next_state is P.HealthStats.IRF:
            self._fimgain_dtof = 18.3
        if next_state is P.HealthStats.SNF:
            self._fimgain_dtof = 16.4
        if next_state is P.HealthStats.HHA:
            self._fimgain_dtof = 10
        if next_state is P.HealthStats.NOCARE:
            self._fimgain_dtof = 5

        # FIM discharge to follow-up
        if next_state is P.HealthStats.IRF:
            self._fimgain_total = 45.0
        if next_state is P.HealthStats.SNF:
            self._fimgain_total = 38.2
        if next_state is P.HealthStats.HHA:
            self._fimgain_total = 20
        if next_state is P.HealthStats.NOCARE:
            self._fimgain_total = 5

        # update current health state
        self._currentState = next_state

    def get_if_alive(self):
        result = True
        if self._currentState == P.HealthStats.IRF:
            result = False
        if self._currentState == P.HealthStats.SNF:
            result = False
        if self._currentState == P.HealthStats.HHA:
            result = False
        if self._currentState == P.HealthStats.NOCARE:
            result = False
        return result

    def get_current_state(self):
        return self._currentState

    def get_survival_time(self):
        """ returns the patient survival time """
        # return survival time only if the patient has died
        if not self.get_if_alive():
            return self._survivalTime
        else:
            return None

    def get_irf_count(self):
        """ returns if discharged to IRF """
        if not self.get_if_alive():
            if self._ifIRF is False:
                return 0
            if self._ifIRF is True:
                return 1
        else:
            return None

    def get_snf_count(self):
        """ returns if discharged to SNF """
        if not self.get_if_alive():
            if self._ifSNF is False:
                return 0
            if self._ifSNF is True:
                return 1
        else:
            return None

    def get_hha_count(self):
        """ returns if discharged to HHA """
        if not self.get_if_alive():
            if self._ifHHA is False:
                return 0
            if self._ifHHA is True:
                return 1
        else:
            return None

    def get_nocare_count(self):
        """ returns if discharged with no care """
        if not self.get_if_alive():
            if self._ifNoCare is False:
                return 0
            if self._ifNoCare is True:
                return 1
        else:
            return None

    def get_los_count(self):
        if not self.get_if_alive():
            return self._los
        else:
            return None

    def get_ambulation_count(self):
        if not self.get_if_alive():
            return self._ambulation
        else:
            return None

    def get_ottime_count(self):
        if not self.get_if_alive():
            return self._ottime
        else:
            return None

    def get_pttime_count(self):
        if not self.get_if_alive():
            return self._pttime
        else:
            return None

    def get_psychtime_count(self):
        if not self.get_if_alive():
            return self._psychtime
        else:
            return None

    def get_otdays_count(self):
        if not self.get_if_alive():
            return self._otdays
        else:
            return None

    def get_ptdays_count(self):
        if not self.get_if_alive():
            return self._ptdays
        else:
            return None

    def get_psychdays_count(self):
        if not self.get_if_alive():
            return self._psychdays
        else:
            return None

    def get_intensity_count(self):
        if not self.get_if_alive():
            return self._intensity
        else:
            return None

    def get_motorfim_count(self):
        if not self.get_if_alive():
            return self._motorfim
        else:
            return None

    def get_pcs_count(self):
        if not self.get_if_alive():
            return self._pcs
        else:
            return None

    def get_mcs_count(self):
        if not self.get_if_alive():
            return self._mcs
        else:
            return None

    def get_fimgain_atod_count(self):
        if not self.get_if_alive():
            return self._fimgain_atod
        else:
            return None

    def get_fimgain_dtof_count(self):
        if not self.get_if_alive():
            return self._fimgain_dtof
        else:
            return None

    def get_fimgain_total_count(self):
        if not self.get_if_alive():
            return self._fimgain_total
        else:
            return None


class Cohort:
    def __init__(self, id, therapy):
        """ create a cohort of patients
        :param id: an integer to specify the seed of the random number generator
        """
        self._initial_pop_size = Data.POP_SIZE
        self._patients = []      # list of patients

        # populate the cohort
        for i in range(self._initial_pop_size):
            # create a new patient (use id * pop_size + i as patient id)
            patient = Patient(id * self._initial_pop_size + i, P.ParametersFixed(therapy))
            # add the patient to the cohort
            self._patients.append(patient)

    def simulate(self):
        """ simulate the cohort of patients over the specified number of time-steps
        :returns outputs from simulating this cohort
        """

        # simulate all patients
        for patient in self._patients:
            patient.simulate(Data.SIM_LENGTH)

        # return the cohort outputs
        return CohortOutputs(self)

    def get_initial_pop_size(self):
        return self._initial_pop_size

    def get_patients(self):
        return self._patients


class CohortOutputs:
    def __init__(self, simulated_cohort):
        """ extracts outputs from a simulated cohort
        :param simulated_cohort: a cohort after being simulated
        """

        self._survivalTimes = []
        self._irf_count = []
        self._snf_count = []
        self._hha_count = []
        self._nocare_count = []

        self._los_count = []
        self._ambulation_count = []
        self._pttime_count = []
        self._ottime_count = []
        self._psychtime_count = []
        self._intensity_count = []
        self._ptdays_count = []
        self._otdays_count = []
        self._psychdays_count = []

        self._motorfim_count = []
        self._pcs_count = []
        self._mcs_count = []
        self._fimgain_total_count = []
        self._fimgain_dtof_count = []
        self._fimgain_atod_count = []

        # survival curve
        self._survivalCurve = \
            PathCls.SamplePathBatchUpdate('Population size over time', id, simulated_cohort.get_initial_pop_size())

        # find patients' survival times
        for patient in simulated_cohort.get_patients():

            # get the patient survival time
            survival_time = patient.get_survival_time()
            if not (survival_time is None):
                self._survivalTimes.append(survival_time)           # store the survival time of this patient
                self._survivalCurve.record(survival_time, -1)       # update the survival curve

            # IRF count
            irf_count = patient.get_irf_count()
            if not (irf_count is None):
                self._irf_count.append(irf_count)

            # SNF count
            snf_count = patient.get_snf_count()
            if not (snf_count is None):
                self._snf_count.append(snf_count)

            # HHA count
            hha_count = patient.get_hha_count()
            if not (hha_count is None):
                self._hha_count.append(hha_count)

            # No care count
            nocare_count = patient.get_nocare_count()
            if not (nocare_count is None):
                self._nocare_count.append(nocare_count)


            # los count
            los_count = patient.get_los_count()
            if not (los_count is None):
                self._los_count.append(los_count)

            # ambualtion count
            ambulation_count = patient.get_ambulation_count()
            if not (ambulation_count is None):
                self._ambulation_count.append(ambulation_count)

            # ot time count
            ottime_count = patient.get_ottime_count()
            if not (ottime_count is None):
                self._ottime_count.append(ottime_count)

            # pt count
            pttime_count = patient.get_pttime_count()
            if not (pttime_count is None):
                self._pttime_count.append(pttime_count)

            # psych count
            psychtime_count = patient.get_psychtime_count()
            if not (psychtime_count is None):
                self._psychtime_count.append(psychtime_count)

            # intensity count
            intensity_count = patient.get_intensity_count()
            if not (intensity_count is None):
                self._intensity_count.append(intensity_count)

            # ot days count
            otdays_count = patient.get_otdays_count()
            if not (otdays_count is None):
                self._otdays_count.append(otdays_count)

            # pt days count
            ptdays_count = patient.get_ptdays_count()
            if not (ptdays_count is None):
                self._ptdays_count.append(ptdays_count)

            # psych days count
            psychdays_count = patient.get_psychdays_count()
            if not (psychdays_count is None):
                self._psychdays_count.append(psychdays_count)


            # motor fim count
            motorfim_count = patient.get_motorfim_count()
            if not (motorfim_count is None):
                self._motorfim_count.append(motorfim_count)

            # pcs count
            pcs_count = patient.get_pcs_count()
            if not (pcs_count is None):
                self._pcs_count.append(pcs_count)

            # mcs count
            mcs_count = patient.get_mcs_count()
            if not (mcs_count is None):
                self._mcs_count.append(mcs_count)

            # fimgain atod count
            fimgain_atod_count = patient.get_fimgain_atod_count()
            if not (fimgain_atod_count is None):
                self._fimgain_atod_count.append(fimgain_atod_count)

            # fim gain dtof count
            fimgain_dtof_count = patient.get_fimgain_dtof_count()
            if not (fimgain_dtof_count is None):
                self._fimgain_dtof_count.append(fimgain_dtof_count)

            # fim gain total count
            fimgain_total_count = patient.get_fimgain_total_count()
            if not (fimgain_total_count is None):
                self._fimgain_total_count.append(fimgain_total_count)


        # summary statistics
        self._sumStat_survivalTime = StatCls.SummaryStat('Patient survival time', self._survivalTimes)
        self._sumStat_irf_count = StatCls.SummaryStat('IRF discharge', self._irf_count)
        self._sumStat_snf_count = StatCls.SummaryStat('SNF discharge', self._snf_count)
        self._sumStat_hha_count = StatCls.SummaryStat('HHA discharge', self._hha_count)
        self._sumStat_nocare_count = StatCls.SummaryStat('Discharged without care', self._nocare_count)


        self._sumStat_los_count = StatCls.SummaryStat('Days in facility-based rehabilitation', self._los_count)
        self._sumStat_ambulation_count = StatCls.SummaryStat('Ambulation distance in feet', self._ambulation_count)
        self._sumStat_ottime_count = StatCls.SummaryStat('OT time in min', self._ottime_count)
        self._sumStat_pttime_count = StatCls.SummaryStat('PT time in min', self._pttime_count)
        self._sumStat_psychtime_count = StatCls.SummaryStat('Counseling time in min', self._psychtime_count)
        self._sumStat_intensity_count = StatCls.SummaryStat('Intensity of rehabilitation min/days in rehab', self._intensity_count)
        self._sumStat_otdays_count = StatCls.SummaryStat('Days of OT', self._otdays_count)
        self._sumStat_ptdays_count = StatCls.SummaryStat('Days of PT', self._ptdays_count)
        self._sumStat_psychdays_count = StatCls.SummaryStat('Days of counseling', self._psychdays_count)


        self._sumStat_motorfim_count = StatCls.SummaryStat('FIM motor score', self._motorfim_count)
        self._sumStat_pcs_count = StatCls.SummaryStat('Transformed PCS score', self._pcs_count)
        self._sumStat_mcs_count = StatCls.SummaryStat('Transformed MCS score', self._mcs_count)
        self._sumStat_fimgain_total_count = StatCls.SummaryStat('Total FIM gain', self._fimgain_total_count)
        self._sumStat_fimgain_atod_count = StatCls.SummaryStat('FIM gain admission to discharge', self._fimgain_atod_count)
        self._sumStat_fimgain_dtof_count = StatCls.SummaryStat('FIM gain post-discharge', self._fimgain_dtof_count)


    def get_sumStat_irf_count(self):
        return self._sumStat_irf_count

    def get_sumStat_snf_count(self):
        return self._sumStat_snf_count

    def get_sumStat_hha_count(self):
        return self._sumStat_hha_count

    def get_sumStat_nocare_count(self):
        return self._sumStat_nocare_count

    def get_irf_count(self):
        return self._irf_count

    def get_snf_count(self):
        return self._snf_count

    def get_hha_count(self):
        return self._hha_count

    def get_nocare_count(self):
        return self._nocare_count

    def get_survival_times(self):
        return self._survivalTimes

    def get_sumStat_survival_times(self):
        return self._sumStat_survivalTime

    def get_survival_curve(self):
        return self._survivalCurve


    def get_sumStat_los_count(self):
        return self._sumStat_los_count

    def get_sumStat_ambulation_count(self):
        return self._sumStat_ambulation_count

    def get_sumStat_intensity_count(self):
        return self._sumStat_intensity_count

    def get_sumStat_pttime_count(self):
        return self._sumStat_pttime_count

    def get_sumStat_ottime_count(self):
        return self._sumStat_ottime_count

    def get_sumStat_psychtime_count(self):
        return self._sumStat_psychtime_count

    def get_sumStat_ptdays_count(self):
        return self._sumStat_ptdays_count

    def get_sumStat_otdays_count(self):
        return self._sumStat_otdays_count

    def get_sumStat_psychdays_count(self):
        return self._sumStat_psychdays_count


    def get_sumStat_motorfim_count(self):
        return self._sumStat_motorfim_count

    def get_sumStat_pcs_count(self):
        return self._sumStat_pcs_count

    def get_sumStat_mcs_count(self):
        return self._sumStat_mcs_count

    def get_sumStat_fimgain_total_count(self):
        return self._sumStat_fimgain_total_count

    def get_sumStat_fimgain_atod_count(self):
        return self._sumStat_fimgain_atod_count

    def get_sumStat_fimgain_dtof_count(self):
        return self._sumStat_fimgain_dtof_count


    def get_los_count(self):
        return self._los_count

    def get_ambulation_count(self):
        return self._ambulation_count

    def get_intensity_count(self):
        return self._intensity_count

    def get_pttime_count(self):
        return self._pttime_count

    def get_ottime_count(self):
        return self._ottime_count

    def get_psychtime_count(self):
        return self._psychtime_count

    def get_ptdays_count(self):
        return self._ptdays_count

    def get_otdays_count(self):
        return self._otdays_count

    def get_psychdays_count(self):
        return self._psychdays_count


    def get_motorfim_count(self):
        return self._motorfim_count

    def get_pcs_count(self):
        return self._pcs_count

    def get_mcs_count(self):
        return self._mcs_count

    def get_fimgain_total_count(self):
        return self._fimgain_total_count

    def get_fimgain_atod_count(self):
        return self._fimgain_atod_count

    def get_fimgain_dtof_count(self):
        return self._fimgain_dtof_count
